CARA PASANG WORKFLOW

1. Extract ZIP ini
2. Upload folder .github ke repo GitHub kamu
3. Tambahkan GitHub Secret:
BOT_TOKEN = token bot Telegram

Workflow:
.github/workflows/build.yml
